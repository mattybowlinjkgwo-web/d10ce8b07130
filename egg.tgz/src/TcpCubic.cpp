// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate CUBIC growth\n", stdout);
  return lionss_run_workload("TcpCubic");
}
