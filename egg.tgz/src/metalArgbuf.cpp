// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode argument buffer\n", stdout);
  return lionss_run_workload("metalArgbuf");
}
