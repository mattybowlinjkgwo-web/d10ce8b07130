// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Advance squall line\n", stdout);
  return lionss_run_workload("squall");
}
