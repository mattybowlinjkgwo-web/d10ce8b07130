// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Audit anchor targets\n", stdout);
  return lionss_run_workload("anchorAudit");
}
